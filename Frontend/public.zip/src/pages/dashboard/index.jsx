import React, { useState, useEffect } from 'react';

const Dashboard = () => {
  const [stats, setStats] = useState({
    total_siswa: 0,
    total_pendaftar: 0,
    total_admin: 0,
    tahun_ajaran: '-',
  });
  const [activities, setActivities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
        
        const res = await fetch(`${API_BASE_URL}/api/dashboard`, {
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (res.ok) {
          const data = await res.json();
          setStats(data.stats);
          setActivities(data.recent_activities);
        }
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, []);
  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 text-slate-800 shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100 relative overflow-hidden animate-fade-up">
        <div className="absolute top-0 left-0 w-1.5 h-full bg-blue-500"></div>
        <div className="relative z-10">
          <h2 className="text-2xl sm:text-3xl font-bold mb-2 text-[#1e293b]">Selamat Datang di Sistem Informasi!</h2>
          <p className="text-slate-500 text-sm max-w-xl">
            Sistem Informasi SMAN 1 Pamekasan. Kelola data sekolah dengan efisiensi dan mudah melalui platform terpadu.
          </p>
        </div>
      </div>

      {/* Grid Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 animate-fade-up delay-75">
        {/* Stat Card 1 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[12px] font-bold text-slate-500 uppercase tracking-wider">Total Siswa</h3>
            <span className="p-2 bg-blue-50 text-blue-500 rounded-lg">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </span>
          </div>
          {isLoading ? (
             <div className="h-8 w-16 bg-slate-200 animate-pulse rounded"></div>
          ) : (
             <p className="text-3xl font-bold text-[#1e293b]">{stats.total_siswa.toLocaleString()}</p>
          )}
          <div className="mt-2 flex items-center text-[11px] font-medium text-slate-400 gap-1">
            <span>Keseluruhan siswa terdaftar</span>
          </div>
        </div>

        {/* Stat Card 2 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[12px] font-bold text-slate-500 uppercase tracking-wider">Total Pendaftar</h3>
            <span className="p-2 bg-purple-50 text-purple-500 rounded-lg">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            </span>
          </div>
          {isLoading ? (
             <div className="h-8 w-16 bg-slate-200 animate-pulse rounded"></div>
          ) : (
             <p className="text-3xl font-bold text-[#1e293b]">{stats.total_pendaftar.toLocaleString()}</p>
          )}
          <div className="mt-2 flex items-center text-[11px] font-medium text-slate-400 gap-1">
            <span>Menunggu migrasi atau verifikasi</span>
          </div>
        </div>

        {/* Stat Card 3 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[12px] font-bold text-slate-500 uppercase tracking-wider">Tahun Ajaran</h3>
            <span className="p-2 bg-amber-50 text-amber-500 rounded-lg">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </span>
          </div>
          {isLoading ? (
             <div className="h-8 w-24 bg-slate-200 animate-pulse rounded"></div>
          ) : (
             <p className="text-3xl font-bold text-[#1e293b]">{stats.tahun_ajaran}</p>
          )}
          <div className="mt-2 flex items-center text-[11px] font-medium text-amber-500 gap-1">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            <span>Saat ini aktif</span>
          </div>
        </div>

        {/* Stat Card 4 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[12px] font-bold text-slate-500 uppercase tracking-wider">Total Admin</h3>
            <span className="p-2 bg-emerald-50 text-emerald-500 rounded-lg">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </span>
          </div>
          {isLoading ? (
             <div className="h-8 w-16 bg-slate-200 animate-pulse rounded"></div>
          ) : (
             <p className="text-3xl font-bold text-[#1e293b]">{stats.total_admin}</p>
          )}
          <div className="mt-2 flex items-center text-[11px] font-medium text-emerald-500 gap-1">
            <span>Admin Sistem</span>
          </div>
        </div>
      </div>

      {/* Main Content Areas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recent Activity Table */}
        <div className="bg-white rounded-2xl p-6 lg:col-span-2 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] animate-fade-up delay-150">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-[16px] font-bold text-[#1e293b]">Aktivitas Terkini</h3>
            <button className="text-[12px] font-semibold text-blue-500 hover:text-blue-600 transition-colors">
              Lihat Semua
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="pb-3 pl-2">Aktivitas</th>
                  <th className="pb-3">Oleh</th>
                  <th className="pb-3">Tanggal</th>
                  <th className="pb-3 text-right pr-2">Status</th>
                </tr>
              </thead>
              <tbody className="text-[13px] text-slate-600">
                {isLoading ? (
                  <tr>
                    <td colSpan="4" className="py-8 text-center text-slate-400">
                      <div className="flex justify-center mb-2">
                        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                      </div>
                      Memuat aktivitas...
                    </td>
                  </tr>
                ) : activities.length > 0 ? (
                  activities.map((item, i) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 pl-2 font-medium text-slate-700">{item.act}</td>
                      <td className="py-4">{item.by}</td>
                      <td className="py-4 text-slate-400 text-[12px]">{item.date}</td>
                      <td className="py-4 text-right pr-2">
                        <span className={`inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${item.statusColor}`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="py-8 text-center text-slate-400">
                      Tidak ada aktivitas terbaru.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions Panel */}
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] animate-fade-up delay-300">
          <h3 className="text-[16px] font-bold text-[#1e293b] mb-6">Tindakan Cepat</h3>
          <div className="space-y-3">
            {[
              { icon: 'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z', label: 'Tambah Siswa Baru', colorClass: 'bg-blue-50 text-blue-500 group-hover:bg-blue-100' },
              { icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01', label: 'Laporan Kehadiran', colorClass: 'bg-emerald-50 text-emerald-500 group-hover:bg-emerald-100' },
              { icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z', label: 'Pengaturan Sistem', colorClass: 'bg-slate-50 text-slate-500 group-hover:bg-slate-100' }
            ].map((action, i) => (
              <button key={i} className="w-full flex items-center gap-4 p-3 rounded-xl border border-slate-100 hover:border-slate-200 hover:bg-slate-50 hover:shadow-sm transition-all text-left group">
                <span className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${action.colorClass}`}>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={action.icon} />
                  </svg>
                </span>
                <span className="text-[13px] font-bold text-slate-700 group-hover:text-blue-600 transition-colors">
                  {action.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};

export default Dashboard;
